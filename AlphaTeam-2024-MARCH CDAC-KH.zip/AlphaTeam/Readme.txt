

1]Create SQL Table from SQL_Tables,txt
2]Before Running app.py Make sure your Sql Credintials are Right
3]To Login check your admin username and passward
